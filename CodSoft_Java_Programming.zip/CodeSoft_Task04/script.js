document.getElementById('currency-form').addEventListener('submit', function(event) {
    event.preventDefault();
  
    let amount = document.getElementById('amount').value;
    let fromCurrency = document.getElementById('from-currency').value;
    let toCurrency = document.getElementById('to-currency').value;
  
    // Example API: https://api.exchangerate-api.com/v4/latest/USD
    const apiKey = 'YOUR_API_KEY'; // Replace with your actual API key
    let url = `https://v6.exchangerate-api.com/v6/${apiKey}/latest/${fromCurrency}`;
  
    fetch(url)
      .then(response => response.json())
      .then(data => {
        let rate = data.conversion_rates[toCurrency];
        let convertedAmount = (amount * rate).toFixed(2);
        
        document.getElementById('result').textContent = `${amount} ${fromCurrency} = ${convertedAmount} ${toCurrency}`;
      })
      .catch(error => {
        console.error('Error fetching the exchange rate:', error);
        document.getElementById('result').textContent = 'Something went wrong. Please try again.';
      });
  });
  