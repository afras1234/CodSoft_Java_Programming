package Task03;

class BankAccount {
    private double balance;

    // Constructor to initialize the balance
    public BankAccount(double initialBalance) {
        this.balance = initialBalance;
    }

    // Method to get the current balance
    public double getBalance() {
        return balance;
    }

    // Method to decrease balance on withdrawal
    public void decreaseBalance(double amount) {
        this.balance -= amount;
    }

    // Method to increase balance on deposit
    public void increaseBalance(double amount) {
        this.balance += amount;
    }
}

