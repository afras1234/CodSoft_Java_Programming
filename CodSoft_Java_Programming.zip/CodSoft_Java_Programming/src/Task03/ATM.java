package Task03;

class ATM {
    private BankAccount account;

    // Constructor to initialize the ATM with a bank account
    public ATM(BankAccount account) {
        this.account = account;
    }

    // Method for withdrawing money
    public void withdraw(double amount) {
        if (amount > 0 && account.getBalance() >= amount) {
            account.decreaseBalance(amount);
            System.out.println("You have successfully withdrawn: $" + amount);
        } else if (amount <= 0) {
            System.out.println("Enter a valid amount to withdraw.");
        } else {
            System.out.println("Insufficient balance for this withdrawal.");
        }
        checkBalance();
    }

    // Method for depositing money
    public void deposit(double amount) {
        if (amount > 0) {
            account.increaseBalance(amount);
            System.out.println("You have successfully deposited: $" + amount);
        } else {
            System.out.println("Enter a valid amount to deposit.");
        }
        checkBalance();
    }

    // Method for checking balance
    public void checkBalance() {
        System.out.println("Current Balance: $" + account.getBalance());
    }

    // ATM Menu for interaction
    public void showMenu() {
        System.out.println("ATM Menu:");
        System.out.println("1. Withdraw");
        System.out.println("2. Deposit");
        System.out.println("3. Check Balance");
        System.out.println("4. Exit");
    }
}
