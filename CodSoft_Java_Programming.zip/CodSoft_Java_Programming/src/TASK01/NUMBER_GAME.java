package TASK01;
import java.util.Random;
import java.util.Scanner;

public class NUMBER_GAME {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        boolean playAgain = true;
        int totalScore = 0;

        System.out.println("Welcome to the Number Guessing Game!");

        while (playAgain) {
            int attempts = 0;
            int maxAttempts = 5;
            int randomNumber = random.nextInt(100) + 1;
            boolean guessedCorrectly = false;

            System.out.println("I have selected a number between 1 and 100. Try to guess it!");

            // Loop for limited attempts
            while (attempts < maxAttempts && !guessedCorrectly) {
                System.out.print("Enter your guess (Attempt " + (attempts + 1) + " of " + maxAttempts + "): ");
                int userGuess = scanner.nextInt();
                attempts++;

                if (userGuess == randomNumber) {
                    System.out.println("Congratulations! You guessed the correct number.");
                    guessedCorrectly = true;
                    totalScore += (maxAttempts - attempts + 1); // Higher score for fewer attempts
                } else if (userGuess > randomNumber) {
                    System.out.println("Your guess is too high.");
                } else {
                    System.out.println("Your guess is too low.");
                }

                if (!guessedCorrectly && attempts == maxAttempts) {
                    System.out.println("Sorry, you've used all your attempts. The correct number was " + randomNumber);
                }
            }

            // Prompt user to play again
            System.out.print("Would you like to play another round? (yes/no): ");
            String userResponse = scanner.next().toLowerCase();

            if (!userResponse.equals("yes")) {
                playAgain = false;
                System.out.println("Thank you for playing! Your total score is: " + totalScore);
            }
        }

        scanner.close();
    }
}
